#!/bin/bash
makepkg
